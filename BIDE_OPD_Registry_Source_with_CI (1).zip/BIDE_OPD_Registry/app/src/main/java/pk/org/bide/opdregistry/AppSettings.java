package pk.org.bide.opdregistry;

import android.content.Context;
import android.content.SharedPreferences;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class AppSettings {
    private static final String PREFS = "bide_opd_settings";
    private static final String KEY_VISIT_TYPES = "visit_types";
    private static final String KEY_STATUSES = "statuses";
    private static final String KEY_PIN_HASH = "pin_hash";
    private static final String KEY_PIN_SALT = "pin_salt";

    private final SharedPreferences prefs;

    public AppSettings(Context context) {
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public List<String> getVisitTypes() {
        return splitOrDefault(KEY_VISIT_TYPES,
                Arrays.asList("New Patient", "Follow-up", "Walk-in", "Diabetes Clinic", "Endocrine Clinic", "Teleconsultation", "Other"));
    }

    public List<String> getStatuses() {
        return splitOrDefault(KEY_STATUSES,
                Arrays.asList("Scheduled", "Checked In", "Completed", "Cancelled", "Missed", "Rescheduled"));
    }

    public void setVisitTypes(List<String> values) {
        prefs.edit().putString(KEY_VISIT_TYPES, joinClean(values)).apply();
    }

    public void setStatuses(List<String> values) {
        prefs.edit().putString(KEY_STATUSES, joinClean(values)).apply();
    }

    private List<String> splitOrDefault(String key, List<String> defaults) {
        String raw = prefs.getString(key, "");
        if (raw == null || raw.trim().isEmpty()) return new ArrayList<>(defaults);
        ArrayList<String> result = new ArrayList<>();
        for (String s : raw.split("\\|")) {
            String t = s.trim();
            if (!t.isEmpty()) result.add(t);
        }
        return result.isEmpty() ? new ArrayList<>(defaults) : result;
    }

    private String joinClean(List<String> values) {
        StringBuilder sb = new StringBuilder();
        for (String s : values) {
            String t = s == null ? "" : s.trim().replace("|", "");
            if (t.isEmpty()) continue;
            if (sb.length() > 0) sb.append('|');
            sb.append(t);
        }
        return sb.toString();
    }

    public boolean hasPin() {
        return prefs.contains(KEY_PIN_HASH) && prefs.contains(KEY_PIN_SALT);
    }

    public boolean setPin(String pin) {
        if (pin == null || !pin.matches("\\d{4,8}")) return false;
        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);
        String saltHex = toHex(salt);
        String hash = hash(pin, saltHex);
        prefs.edit().putString(KEY_PIN_SALT, saltHex).putString(KEY_PIN_HASH, hash).apply();
        return true;
    }

    public boolean verifyPin(String pin) {
        String salt = prefs.getString(KEY_PIN_SALT, null);
        String expected = prefs.getString(KEY_PIN_HASH, null);
        if (salt == null || expected == null || pin == null) return false;
        return constantTimeEquals(expected, hash(pin, salt));
    }

    private String hash(String pin, String saltHex) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(saltHex.getBytes(StandardCharsets.UTF_8));
            md.update((byte)':');
            md.update(pin.getBytes(StandardCharsets.UTF_8));
            return toHex(md.digest());
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    private boolean constantTimeEquals(String a, String b) {
        if (a.length() != b.length()) return false;
        int diff = 0;
        for (int i = 0; i < a.length(); i++) diff |= a.charAt(i) ^ b.charAt(i);
        return diff == 0;
    }

    private String toHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) sb.append(String.format("%02x", b & 0xff));
        return sb.toString();
    }
}
