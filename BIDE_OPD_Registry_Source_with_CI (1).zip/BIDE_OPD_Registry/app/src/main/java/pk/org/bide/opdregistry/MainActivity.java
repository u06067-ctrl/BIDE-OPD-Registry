package pk.org.bide.opdregistry;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity {
    private static final int REQ_XLSX = 201;
    private static final int REQ_CSV = 202;
    private static final int REQ_BACKUP = 203;
    private static final int REQ_RESTORE = 204;

    private final int BLUE = Color.rgb(11, 92, 173);
    private final int DARK = Color.rgb(23, 33, 43);
    private final int MUTED = Color.rgb(91, 103, 115);
    private final int BG = Color.rgb(245, 247, 250);

    private DbHelper db;
    private AppSettings settings;
    private FrameLayout content;
    private TextView headerTitle;
    private QueryFilter activeFilter = new QueryFilter();
    private List<VisitRecord> currentRecords = new ArrayList<>();
    private List<VisitRecord> pendingExportRecords = new ArrayList<>();
    private String pendingExportScope = "Export";
    private boolean unlocked = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        db = new DbHelper(this);
        settings = new AppSettings(this);
        buildShell();
        showPinGate();
    }

    private void buildShell() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        headerTitle = new TextView(this);
        headerTitle.setText("BIDE Karachi OPD Registry");
        headerTitle.setTextColor(Color.WHITE);
        headerTitle.setTextSize(20);
        headerTitle.setGravity(Gravity.CENTER_VERTICAL);
        headerTitle.setPadding(dp(18), dp(12), dp(18), dp(12));
        headerTitle.setBackgroundColor(BLUE);
        root.addView(headerTitle, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58)));

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setPadding(dp(6), dp(6), dp(6), dp(6));
        nav.addView(navButton("Dashboard", new View.OnClickListener() { public void onClick(View v) { ifUnlockedDashboard(); }}));
        nav.addView(navButton("Patients", new View.OnClickListener() { public void onClick(View v) { if (unlocked) showPatients(); }}));
        nav.addView(navButton("Add Visit", new View.OnClickListener() { public void onClick(View v) { if (unlocked) showVisitForm(null); }}));
        nav.addView(navButton("Export", new View.OnClickListener() { public void onClick(View v) { if (unlocked) showExport(); }}));
        nav.addView(navButton("Settings", new View.OnClickListener() { public void onClick(View v) { if (unlocked) showSettings(); }}));
        hsv.addView(nav);
        root.addView(hsv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)));

        content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);
    }

    private Button navButton(String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(13);
        b.setAllCaps(false);
        b.setOnClickListener(listener);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(105), dp(42));
        lp.setMargins(dp(3), 0, dp(3), 0);
        b.setLayoutParams(lp);
        return b;
    }

    private void ifUnlockedDashboard() {
        if (unlocked) showDashboard();
    }

    private void showPinGate() {
        if (settings.hasPin()) showUnlockDialog();
        else showCreatePinDialog();
    }

    private void showCreatePinDialog() {
        final LinearLayout box = dialogBox();
        final EditText pin1 = pinField("Create 4–8 digit staff PIN");
        final EditText pin2 = pinField("Confirm PIN");
        box.addView(helpText("Patient data is kept in the app's private storage. A staff PIN is required before records can be viewed."));
        box.addView(pin1); box.addView(pin2);
        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Secure first-time setup")
                .setView(box)
                .setCancelable(false)
                .setPositiveButton("Create PIN", null)
                .create();
        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String a = pin1.getText().toString();
            String b = pin2.getText().toString();
            if (!a.matches("\\d{4,8}")) { pin1.setError("Use 4–8 digits"); return; }
            if (!a.equals(b)) { pin2.setError("PINs do not match"); return; }
            settings.setPin(a);
            unlocked = true;
            dialog.dismiss();
            showDashboard();
        }));
        dialog.show();
    }

    private void showUnlockDialog() {
        final LinearLayout box = dialogBox();
        final EditText pin = pinField("Staff PIN");
        box.addView(pin);
        final AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Unlock BIDE OPD Registry")
                .setView(box)
                .setCancelable(false)
                .setPositiveButton("Unlock", null)
                .setNegativeButton("Exit", (d, w) -> finish())
                .create();
        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            if (!settings.verifyPin(pin.getText().toString())) {
                pin.setError("Incorrect PIN");
                return;
            }
            unlocked = true;
            dialog.dismiss();
            showDashboard();
        }));
        dialog.show();
    }

    private EditText pinField(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        e.setSingleLine(true);
        e.setPadding(dp(12), dp(8), dp(12), dp(8));
        return e;
    }

    private LinearLayout dialogBox() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), dp(4));
        return box;
    }

    private void setScreen(String title, View view) {
        headerTitle.setText(title);
        content.removeAllViews();
        content.addView(view, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private void showDashboard() {
        ScrollView sv = new ScrollView(this);
        LinearLayout box = screenBox();
        sv.addView(box);
        Map<String, Integer> c = db.dashboardCounts();

        box.addView(sectionTitle("OPD overview"));
        LinearLayout row1 = new LinearLayout(this); row1.setOrientation(LinearLayout.HORIZONTAL);
        row1.addView(metric("Patients", c.get("patients")), weight());
        row1.addView(metric("Total visits", c.get("visits")), weight());
        box.addView(row1);
        LinearLayout row2 = new LinearLayout(this); row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.addView(metric("Visits today", c.get("today")), weight());
        row2.addView(metric("Next 7 days", c.get("upcoming7")), weight());
        box.addView(row2);
        LinearLayout row3 = new LinearLayout(this); row3.setOrientation(LinearLayout.HORIZONTAL);
        row3.addView(metric("Scheduled", c.get("scheduled")), weight());
        row3.addView(metric("Completed", c.get("completed")), weight());
        row3.addView(metric("Missed", c.get("missed")), weight());
        box.addView(row3);

        Button add = primaryButton("+ Register visit / appointment");
        add.setOnClickListener(v -> showVisitForm(null));
        box.addView(add, blockMargins());

        box.addView(sectionTitle("Today's visit list"));
        List<VisitRecord> today = db.todayVisits();
        if (today.isEmpty()) box.addView(helpText("No visits are recorded for " + db.today() + "."));
        else {
            int max = Math.min(today.size(), 10);
            for (int i = 0; i < max; i++) {
                VisitRecord r = today.get(i);
                TextView t = recordSummary(r);
                t.setOnClickListener(v -> showRecordDetails(r));
                box.addView(t, cardMargins());
            }
            if (today.size() > 10) box.addView(helpText("Showing 10 of " + today.size() + " visits. Open Patients for the full list."));
        }
        setScreen("BIDE Karachi OPD Registry", sv);
    }

    private TextView metric(String label, Integer value) {
        TextView t = new TextView(this);
        t.setText((value == null ? 0 : value) + "\n" + label);
        t.setTextColor(DARK);
        t.setTextSize(17);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(8), dp(18), dp(8), dp(18));
        t.setBackgroundColor(Color.WHITE);
        return t;
    }

    private LinearLayout.LayoutParams weight() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(4), dp(4), dp(4), dp(4));
        return lp;
    }

    private void showPatients() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(10), dp(8), dp(10), dp(8));

        final EditText search = new EditText(this);
        search.setHint("Search MR number, contact or remarks");
        search.setSingleLine(true);
        search.setText(activeFilter.search);
        root.addView(search, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));

        LinearLayout filters = new LinearLayout(this); filters.setOrientation(LinearLayout.HORIZONTAL);
        final Spinner type = spinner(withAll(settings.getVisitTypes()));
        final Spinner status = spinner(withAll(settings.getStatuses()));
        selectSpinner(type, activeFilter.visitType); selectSpinner(status, activeFilter.status);
        filters.addView(type, weight()); filters.addView(status, weight());
        root.addView(filters);

        LinearLayout dates = new LinearLayout(this); dates.setOrientation(LinearLayout.HORIZONTAL);
        final Button from = smallButton(activeFilter.fromDate.isEmpty() ? "From date" : "From: " + activeFilter.fromDate);
        final Button to = smallButton(activeFilter.toDate.isEmpty() ? "To date" : "To: " + activeFilter.toDate);
        final Button clear = smallButton("Clear");
        dates.addView(from, weight()); dates.addView(to, weight()); dates.addView(clear, weight());
        root.addView(dates);

        LinearLayout options = new LinearLayout(this); options.setOrientation(LinearLayout.HORIZONTAL); options.setGravity(Gravity.CENTER_VERTICAL);
        final CheckBox upcoming = new CheckBox(this); upcoming.setText("Next 30 days"); upcoming.setChecked(activeFilter.upcomingOnly);
        final Spinner sort = spinner(list("Visit date (newest)", "Visit date (oldest)", "Next appointment (soonest)", "MR number"));
        selectSpinner(sort, activeFilter.sort);
        options.addView(upcoming, weight()); options.addView(sort, weight());
        root.addView(options);

        final TextView resultCount = helpText("");
        root.addView(resultCount);
        final ListView listView = new ListView(this);
        listView.setDividerHeight(dp(6));
        root.addView(listView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        final Runnable refresh = new Runnable() {
            public void run() {
                activeFilter.search = search.getText().toString().trim();
                activeFilter.visitType = String.valueOf(type.getSelectedItem());
                activeFilter.status = String.valueOf(status.getSelectedItem());
                activeFilter.upcomingOnly = upcoming.isChecked();
                activeFilter.upcomingDays = 30;
                activeFilter.sort = String.valueOf(sort.getSelectedItem());
                currentRecords = db.query(activeFilter);
                resultCount.setText(currentRecords.size() + " matching visit record" + (currentRecords.size() == 1 ? "" : "s"));
                listView.setAdapter(new VisitAdapter(currentRecords));
            }
        };

        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            public void onTextChanged(CharSequence s, int st, int b, int c) { refresh.run(); }
            public void afterTextChanged(Editable e) {}
        });
        AdapterView.OnItemSelectedListener listener = new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> p, View v, int pos, long id) { refresh.run(); }
            public void onNothingSelected(AdapterView<?> p) {}
        };
        type.setOnItemSelectedListener(listener); status.setOnItemSelectedListener(listener); sort.setOnItemSelectedListener(listener);
        upcoming.setOnCheckedChangeListener((buttonView, isChecked) -> refresh.run());
        from.setOnClickListener(v -> pickDate(activeFilter.fromDate, value -> {
            activeFilter.fromDate = value; from.setText("From: " + value); refresh.run();
        }));
        to.setOnClickListener(v -> pickDate(activeFilter.toDate, value -> {
            activeFilter.toDate = value; to.setText("To: " + value); refresh.run();
        }));
        clear.setOnClickListener(v -> {
            activeFilter = new QueryFilter();
            showPatients();
        });
        listView.setOnItemClickListener((parent, view, position, id) -> showRecordDetails(currentRecords.get(position)));
        refresh.run();
        setScreen("Patient & Visit Records", root);
    }

    private class VisitAdapter extends BaseAdapter {
        private final List<VisitRecord> data;
        VisitAdapter(List<VisitRecord> data) { this.data = data; }
        public int getCount() { return data.size(); }
        public Object getItem(int p) { return data.get(p); }
        public long getItemId(int p) { return data.get(p).visitId; }
        public View getView(int p, View convertView, ViewGroup parent) {
            VisitRecord r = data.get(p);
            LinearLayout box = new LinearLayout(MainActivity.this);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setPadding(dp(14), dp(10), dp(14), dp(10));
            box.setBackgroundColor(Color.WHITE);
            TextView a = new TextView(MainActivity.this);
            a.setText("MR " + r.mrNumber + "  •  " + r.status);
            a.setTextSize(16); a.setTextColor(DARK);
            TextView b = new TextView(MainActivity.this);
            b.setText(r.visitDate + "  |  " + r.visitType + (r.nextAppointment.isEmpty() ? "" : "  |  Next: " + r.nextAppointment));
            b.setTextSize(13); b.setTextColor(MUTED);
            TextView c = new TextView(MainActivity.this);
            c.setText("Contact: " + blankDash(r.contact) + (r.remarks.isEmpty() ? "" : "\n" + truncate(r.remarks, 90)));
            c.setTextSize(13); c.setTextColor(MUTED);
            box.addView(a); box.addView(b); box.addView(c);
            return box;
        }
    }

    private void showRecordDetails(final VisitRecord r) {
        final VisitRecord fresh = db.getVisit(r.visitId);
        if (fresh == null) { toast("Record no longer exists"); return; }
        List<VisitRecord> history = db.patientHistory(fresh.mrNumber);
        StringBuilder m = new StringBuilder();
        m.append("MR number: ").append(fresh.mrNumber)
                .append("\nContact: ").append(blankDash(fresh.contact))
                .append("\nVisit date: ").append(fresh.visitDate)
                .append("\nVisit type: ").append(fresh.visitType)
                .append("\nNext appointment: ").append(blankDash(fresh.nextAppointment))
                .append("\nStatus: ").append(fresh.status)
                .append("\nRemarks: ").append(blankDash(fresh.remarks))
                .append("\n\nPatient history: ").append(history.size()).append(" visit(s)");
        new AlertDialog.Builder(this)
                .setTitle("Visit details")
                .setMessage(m.toString())
                .setPositiveButton("Edit", (d, w) -> showVisitForm(fresh))
                .setNeutralButton("Add follow-up", (d, w) -> {
                    VisitRecord n = new VisitRecord();
                    n.mrNumber = fresh.mrNumber;
                    n.contact = fresh.contact;
                    n.visitDate = db.today();
                    n.visitType = settings.getVisitTypes().contains("Follow-up") ? "Follow-up" : settings.getVisitTypes().get(0);
                    n.status = settings.getStatuses().contains("Scheduled") ? "Scheduled" : settings.getStatuses().get(0);
                    showVisitForm(n);
                })
                .setNegativeButton("Delete", (d, w) -> confirmDelete(fresh))
                .show();
    }

    private void confirmDelete(final VisitRecord r) {
        new AlertDialog.Builder(this)
                .setTitle("Delete visit record?")
                .setMessage("This deletes this visit for MR " + r.mrNumber + ". If it is the patient's only visit, the patient entry will also be removed.")
                .setPositiveButton("Delete", (d, w) -> {
                    db.deleteVisit(r.visitId);
                    toast("Visit deleted");
                    showPatients();
                })
                .setNegativeButton("Cancel", null).show();
    }

    private void showVisitForm(final VisitRecord original) {
        final boolean editing = original != null && original.visitId > 0;
        final ScrollView sv = new ScrollView(this);
        final LinearLayout box = screenBox(); sv.addView(box);
        box.addView(helpText(editing ? "Update the selected visit record." : "Register an OPD visit or appointment. Existing MR numbers automatically reuse the saved contact number."));

        final EditText mr = field("MR number", InputType.TYPE_CLASS_TEXT);
        final EditText contact = field("Contact number", InputType.TYPE_CLASS_PHONE);
        final Button visitDate = dateButton("Visit date", original == null || empty(original.visitDate) ? db.today() : original.visitDate);
        final Spinner visitType = spinner(settings.getVisitTypes());
        final Button nextDate = dateButton("Next appointment", original == null ? "" : original.nextAppointment);
        final Button clearNext = smallButton("Clear next appointment");
        final Spinner status = spinner(settings.getStatuses());
        final EditText remarks = field("Remarks", InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        remarks.setMinLines(3); remarks.setGravity(Gravity.TOP);

        if (original != null) {
            mr.setText(n(original.mrNumber));
            contact.setText(n(original.contact));
            selectSpinner(visitType, n(original.visitType));
            selectSpinner(status, n(original.status));
            remarks.setText(n(original.remarks));
        } else {
            selectSpinner(status, settings.getStatuses().contains("Scheduled") ? "Scheduled" : settings.getStatuses().get(0));
        }

        box.addView(label("MR number *")); box.addView(mr);
        box.addView(label("Contact number *")); box.addView(contact);
        box.addView(label("Visit date *")); box.addView(visitDate);
        box.addView(label("Visit type *")); box.addView(visitType);
        box.addView(label("Next appointment"));
        LinearLayout nd = new LinearLayout(this); nd.setOrientation(LinearLayout.HORIZONTAL);
        nd.addView(nextDate, new LinearLayout.LayoutParams(0, dp(48), 2f)); nd.addView(clearNext, new LinearLayout.LayoutParams(0, dp(48), 1f));
        box.addView(nd);
        box.addView(label("Status *")); box.addView(status);
        box.addView(label("Remarks")); box.addView(remarks);

        visitDate.setOnClickListener(v -> pickDate((String) visitDate.getTag(), value -> setDateButton(visitDate, "Visit date", value)));
        nextDate.setOnClickListener(v -> pickDate((String) nextDate.getTag(), value -> setDateButton(nextDate, "Next appointment", value)));
        clearNext.setOnClickListener(v -> setDateButton(nextDate, "Next appointment", ""));
        mr.setOnFocusChangeListener((v, hasFocus) -> {
            if (!hasFocus && contact.getText().toString().trim().isEmpty()) {
                String found = db.findContactByMr(mr.getText().toString());
                if (!found.isEmpty()) contact.setText(found);
            }
        });

        Button save = primaryButton(editing ? "Save changes" : "Save visit");
        box.addView(save, blockMargins());
        save.setOnClickListener(v -> {
            String mrVal = mr.getText().toString().trim();
            String contactVal = contact.getText().toString().trim();
            String vd = n((String) visitDate.getTag());
            String ndVal = n((String) nextDate.getTag());
            if (mrVal.isEmpty()) { mr.setError("MR number is required"); return; }
            if (contactVal.isEmpty()) { contact.setError("Contact number is required"); return; }
            if (!validPhone(contactVal)) { contact.setError("Enter a valid contact number (7–15 digits)"); return; }
            if (!ndVal.isEmpty() && ndVal.compareTo(vd) < 0) { toast("Next appointment cannot be earlier than the visit date"); return; }
            VisitRecord r = original == null ? new VisitRecord() : original;
            r.mrNumber = mrVal;
            r.contact = contactVal;
            r.visitDate = vd;
            r.visitType = String.valueOf(visitType.getSelectedItem());
            r.nextAppointment = ndVal;
            r.status = String.valueOf(status.getSelectedItem());
            r.remarks = remarks.getText().toString().trim();
            try {
                db.saveVisit(r);
                toast(editing ? "Visit updated" : "Visit saved");
                showPatients();
            } catch (Exception ex) {
                showError("Could not save record", ex.getMessage());
            }
        });
        setScreen(editing ? "Edit Visit" : "Add Visit / Appointment", sv);
    }

    private void showExport() {
        ScrollView sv = new ScrollView(this);
        LinearLayout box = screenBox(); sv.addView(box);
        box.addView(helpText("Excel export creates a genuine .xlsx workbook with an OPD Records sheet and a Summary sheet. Patient records remain on the device unless a staff member deliberately exports them."));

        final Spinner scope = spinner(list("All records", "Current Patients screen filter", "Custom date / status / type", "Upcoming appointments (next 30 days)", "Today's visits"));
        final Button from = dateButton("From date", "");
        final Button to = dateButton("To date", "");
        final Spinner type = spinner(withAll(settings.getVisitTypes()));
        final Spinner status = spinner(withAll(settings.getStatuses()));
        box.addView(label("Export scope")); box.addView(scope);
        box.addView(label("Custom filters (used for Custom scope)"));
        box.addView(from); box.addView(to); box.addView(type); box.addView(status);
        from.setOnClickListener(v -> pickDate((String) from.getTag(), value -> setDateButton(from, "From date", value)));
        to.setOnClickListener(v -> pickDate((String) to.getTag(), value -> setDateButton(to, "To date", value)));

        Button xlsx = primaryButton("Export Excel (.xlsx)");
        Button csv = secondaryButton("Export CSV (.csv)");
        box.addView(xlsx, blockMargins()); box.addView(csv, blockMargins());

        View.OnClickListener exporter = v -> {
            QueryFilter f = new QueryFilter();
            String label = String.valueOf(scope.getSelectedItem());
            if (label.startsWith("Current")) f = copyFilter(activeFilter);
            else if (label.startsWith("Custom")) {
                f.fromDate = n((String) from.getTag());
                f.toDate = n((String) to.getTag());
                f.visitType = String.valueOf(type.getSelectedItem());
                f.status = String.valueOf(status.getSelectedItem());
            } else if (label.startsWith("Upcoming")) {
                f.upcomingOnly = true; f.upcomingDays = 30; f.sort = "Next appointment (soonest)";
            } else if (label.startsWith("Today")) {
                f.fromDate = db.today(); f.toDate = db.today();
            }
            pendingExportRecords = db.query(f);
            pendingExportScope = label;
            if (pendingExportRecords.isEmpty()) { toast("No records match this export scope"); return; }
            if (v == xlsx) createDocument("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "BIDE_OPD_" + stamp() + ".xlsx", REQ_XLSX);
            else createDocument("text/csv", "BIDE_OPD_" + stamp() + ".csv", REQ_CSV);
        };
        xlsx.setOnClickListener(exporter); csv.setOnClickListener(exporter);

        box.addView(sectionTitle("Available export choices"));
        box.addView(helpText("• All records\n• Whatever is currently filtered on the Patients screen\n• Custom date range + visit type + status\n• Upcoming appointments in the next 30 days\n• Today's visit list\n• Excel (.xlsx) or CSV (.csv)"));
        setScreen("Export OPD Data", sv);
    }

    private void showSettings() {
        ScrollView sv = new ScrollView(this);
        LinearLayout box = screenBox(); sv.addView(box);
        box.addView(sectionTitle("Dropdown configuration"));
        final EditText types = field("Visit types, comma separated", InputType.TYPE_CLASS_TEXT);
        types.setText(join(settings.getVisitTypes()));
        final EditText statuses = field("Statuses, comma separated", InputType.TYPE_CLASS_TEXT);
        statuses.setText(join(settings.getStatuses()));
        box.addView(label("Visit type options")); box.addView(types);
        box.addView(label("Status options")); box.addView(statuses);
        Button saveOptions = primaryButton("Save dropdown options");
        box.addView(saveOptions, blockMargins());
        saveOptions.setOnClickListener(v -> {
            List<String> vt = splitComma(types.getText().toString());
            List<String> st = splitComma(statuses.getText().toString());
            if (vt.isEmpty() || st.isEmpty()) { toast("Each dropdown needs at least one option"); return; }
            settings.setVisitTypes(vt); settings.setStatuses(st);
            toast("Dropdown options saved");
        });

        box.addView(sectionTitle("Security"));
        Button pin = secondaryButton("Change staff PIN"); box.addView(pin, blockMargins());
        pin.setOnClickListener(v -> showChangePinDialog());
        box.addView(helpText("The app requests no Internet permission, disables Android cloud backup, and stores its SQLite database inside the app's private storage. Exported Excel/CSV/backup files should be handled according to BIDE privacy policy."));

        box.addView(sectionTitle("Backup & restore"));
        Button backup = secondaryButton("Create full JSON backup");
        Button restore = secondaryButton("Restore full JSON backup");
        box.addView(backup, blockMargins()); box.addView(restore, blockMargins());
        backup.setOnClickListener(v -> createDocument("application/json", "BIDE_OPD_backup_" + stamp() + ".json", REQ_BACKUP));
        restore.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("application/json");
            startActivityForResult(i, REQ_RESTORE);
        });

        box.addView(sectionTitle("Danger zone"));
        Button wipe = secondaryButton("Delete all patient and visit data"); box.addView(wipe, blockMargins());
        wipe.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Delete ALL data?")
                .setMessage("This cannot be undone unless you have a backup. Export or back up data first.")
                .setPositiveButton("Delete all", (d, w) -> {
                    db.deleteAllData(); toast("All patient data deleted"); showDashboard();
                }).setNegativeButton("Cancel", null).show());

        box.addView(sectionTitle("About this build"));
        box.addView(helpText("BIDE Karachi OPD Registry v1.0.0\nOffline-first administrative registry for MR-based OPD visits and appointments. No clinical decision support is included in this version."));
        setScreen("Settings & Data Management", sv);
    }

    private void showChangePinDialog() {
        LinearLayout box = dialogBox();
        EditText oldPin = pinField("Current PIN");
        EditText newPin = pinField("New 4–8 digit PIN");
        EditText confirm = pinField("Confirm new PIN");
        box.addView(oldPin); box.addView(newPin); box.addView(confirm);
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Change staff PIN").setView(box)
                .setPositiveButton("Change", null).setNegativeButton("Cancel", null).create();
        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            if (!settings.verifyPin(oldPin.getText().toString())) { oldPin.setError("Incorrect current PIN"); return; }
            String p = newPin.getText().toString();
            if (!p.matches("\\d{4,8}")) { newPin.setError("Use 4–8 digits"); return; }
            if (!p.equals(confirm.getText().toString())) { confirm.setError("PINs do not match"); return; }
            settings.setPin(p); dialog.dismiss(); toast("Staff PIN changed");
        }));
        dialog.show();
    }

    private void createDocument(String mime, String name, int request) {
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(mime);
        i.putExtra(Intent.EXTRA_TITLE, name);
        startActivityForResult(i, request);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            if (requestCode == REQ_XLSX) {
                OutputStream out = getContentResolver().openOutputStream(uri);
                if (out == null) throw new IllegalStateException("Unable to open selected file");
                try { XlsxExporter.write(out, pendingExportRecords, pendingExportScope); }
                finally { out.close(); }
                toast("Excel export saved: " + pendingExportRecords.size() + " records");
            } else if (requestCode == REQ_CSV) {
                OutputStream out = getContentResolver().openOutputStream(uri);
                if (out == null) throw new IllegalStateException("Unable to open selected file");
                try { CsvExporter.write(out, pendingExportRecords); }
                finally { out.close(); }
                toast("CSV export saved: " + pendingExportRecords.size() + " records");
            } else if (requestCode == REQ_BACKUP) {
                OutputStream out = getContentResolver().openOutputStream(uri);
                if (out == null) throw new IllegalStateException("Unable to open selected file");
                try { out.write(db.exportJson().toString(2).getBytes(StandardCharsets.UTF_8)); out.flush(); }
                finally { out.close(); }
                toast("Backup saved");
            } else if (requestCode == REQ_RESTORE) {
                final String json = readText(uri);
                new AlertDialog.Builder(this).setTitle("Restore backup?")
                        .setMessage("Restoring will replace all current patient and visit data with the selected backup.")
                        .setPositiveButton("Restore", (d, w) -> {
                            try { db.importJson(new JSONObject(json)); toast("Backup restored"); showDashboard(); }
                            catch (Exception e) { showError("Restore failed", e.getMessage()); }
                        }).setNegativeButton("Cancel", null).show();
            }
        } catch (Exception e) {
            showError("File operation failed", e.getMessage());
        }
    }

    private String readText(Uri uri) throws Exception {
        InputStream in = getContentResolver().openInputStream(uri);
        if (in == null) throw new IllegalStateException("Unable to read selected file");
        try {
            BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
            StringBuilder s = new StringBuilder(); String line;
            while ((line = r.readLine()) != null) s.append(line).append('\n');
            return s.toString();
        } finally { in.close(); }
    }

    private QueryFilter copyFilter(QueryFilter in) {
        QueryFilter f = new QueryFilter();
        f.search = in.search; f.visitType = in.visitType; f.status = in.status;
        f.fromDate = in.fromDate; f.toDate = in.toDate; f.upcomingOnly = in.upcomingOnly;
        f.upcomingDays = in.upcomingDays; f.sort = in.sort;
        return f;
    }

    private boolean validPhone(String value) {
        String digits = value.replaceAll("[^0-9]", "");
        return digits.length() >= 7 && digits.length() <= 15;
    }

    private interface DateReceiver { void accept(String value); }

    private void pickDate(String initial, final DateReceiver receiver) {
        Calendar c = Calendar.getInstance();
        if (initial != null && initial.matches("\\d{4}-\\d{2}-\\d{2}")) {
            try {
                Date d = new SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(initial);
                if (d != null) c.setTime(d);
            } catch (Exception ignored) {}
        }
        DatePickerDialog dlg = new DatePickerDialog(this, (view, year, month, day) -> {
            String value = String.format(Locale.US, "%04d-%02d-%02d", year, month + 1, day);
            receiver.accept(value);
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
        dlg.show();
    }

    private Button dateButton(String label, String value) {
        Button b = smallButton("");
        setDateButton(b, label, value == null ? "" : value);
        return b;
    }

    private void setDateButton(Button b, String label, String value) {
        b.setTag(value == null ? "" : value);
        b.setText(value == null || value.isEmpty() ? label : label + ": " + value);
    }

    private EditText field(String hint, int inputType) {
        EditText e = new EditText(this);
        e.setHint(hint); e.setInputType(inputType); e.setTextSize(15);
        e.setPadding(dp(10), dp(6), dp(10), dp(6));
        e.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return e;
    }

    private Spinner spinner(List<String> values) {
        Spinner s = new Spinner(this);
        ArrayAdapter<String> a = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, values);
        a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        s.setAdapter(a);
        return s;
    }

    private void selectSpinner(Spinner s, String value) {
        if (s.getAdapter() == null || value == null) return;
        for (int i = 0; i < s.getAdapter().getCount(); i++) {
            if (value.equals(String.valueOf(s.getAdapter().getItem(i)))) { s.setSelection(i); return; }
        }
    }

    private List<String> withAll(List<String> values) {
        ArrayList<String> x = new ArrayList<>(); x.add("All"); x.addAll(values); return x;
    }

    private List<String> list(String... values) {
        ArrayList<String> x = new ArrayList<>();
        for (String v : values) x.add(v);
        return x;
    }

    private List<String> splitComma(String raw) {
        ArrayList<String> out = new ArrayList<>();
        if (raw == null) return out;
        for (String p : raw.split(",")) {
            String t = p.trim(); if (!t.isEmpty() && !out.contains(t)) out.add(t);
        }
        return out;
    }

    private String join(List<String> values) {
        StringBuilder s = new StringBuilder();
        for (String v : values) { if (s.length() > 0) s.append(", "); s.append(v); }
        return s.toString();
    }

    private LinearLayout screenBox() {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(10), dp(14), dp(22));
        return box;
    }

    private TextView sectionTitle(String text) {
        TextView t = new TextView(this); t.setText(text); t.setTextSize(18); t.setTextColor(DARK);
        t.setPadding(dp(2), dp(14), dp(2), dp(7));
        return t;
    }

    private TextView label(String text) {
        TextView t = new TextView(this); t.setText(text); t.setTextSize(13); t.setTextColor(MUTED);
        t.setPadding(dp(2), dp(10), dp(2), dp(2));
        return t;
    }

    private TextView helpText(String text) {
        TextView t = new TextView(this); t.setText(text); t.setTextSize(13); t.setTextColor(MUTED);
        t.setPadding(dp(4), dp(8), dp(4), dp(8));
        return t;
    }

    private TextView recordSummary(VisitRecord r) {
        TextView t = new TextView(this);
        t.setText("MR " + r.mrNumber + "  •  " + r.status + "\n" + r.visitType + "  |  " + r.visitDate + (r.nextAppointment.isEmpty() ? "" : "\nNext: " + r.nextAppointment));
        t.setTextColor(DARK); t.setTextSize(14); t.setPadding(dp(12), dp(10), dp(12), dp(10)); t.setBackgroundColor(Color.WHITE);
        return t;
    }

    private Button primaryButton(String text) {
        Button b = new Button(this); b.setText(text); b.setAllCaps(false); b.setTextSize(15);
        return b;
    }

    private Button secondaryButton(String text) {
        Button b = new Button(this); b.setText(text); b.setAllCaps(false); b.setTextSize(14);
        return b;
    }

    private Button smallButton(String text) {
        Button b = new Button(this); b.setText(text); b.setAllCaps(false); b.setTextSize(12);
        return b;
    }

    private LinearLayout.LayoutParams blockMargins() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(8), 0, dp(4)); return lp;
    }

    private LinearLayout.LayoutParams cardMargins() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, dp(4), 0, dp(4)); return lp;
    }

    private void showError(String title, String message) {
        new AlertDialog.Builder(this).setTitle(title).setMessage(message == null ? "Unknown error" : message).setPositiveButton("OK", null).show();
    }

    private void toast(String text) { Toast.makeText(this, text, Toast.LENGTH_SHORT).show(); }
    private int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }
    private boolean empty(String s) { return s == null || s.trim().isEmpty(); }
    private String n(String s) { return s == null ? "" : s; }
    private String blankDash(String s) { return empty(s) ? "—" : s; }
    private String truncate(String s, int max) { return s == null || s.length() <= max ? n(s) : s.substring(0, max - 1) + "…"; }
    private String stamp() { return new SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(new Date()); }
}
