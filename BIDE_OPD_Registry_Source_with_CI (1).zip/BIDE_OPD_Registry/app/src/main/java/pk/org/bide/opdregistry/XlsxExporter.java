package pk.org.bide.opdregistry;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class XlsxExporter {
    private static final String[] HEADERS = {
            "MR Number", "Contact Number", "Visit Date", "Visit Type",
            "Next Appointment", "Status", "Remarks", "Created At", "Updated At"
    };

    public static void write(OutputStream out, List<VisitRecord> records, String scopeLabel) throws Exception {
        ZipOutputStream zip = new ZipOutputStream(out);
        put(zip, "[Content_Types].xml", contentTypes());
        put(zip, "_rels/.rels", rootRels());
        put(zip, "xl/workbook.xml", workbook());
        put(zip, "xl/_rels/workbook.xml.rels", workbookRels());
        put(zip, "xl/styles.xml", styles());
        put(zip, "xl/worksheets/sheet1.xml", recordsSheet(records));
        put(zip, "xl/worksheets/sheet2.xml", summarySheet(records, scopeLabel));
        zip.finish();
        zip.flush();
    }

    private static void put(ZipOutputStream zip, String name, String text) throws Exception {
        zip.putNextEntry(new ZipEntry(name));
        zip.write(text.getBytes(StandardCharsets.UTF_8));
        zip.closeEntry();
    }

    private static String contentTypes() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
                "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
                "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
                "<Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/>" +
                "<Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>" +
                "<Override PartName=\"/xl/worksheets/sheet2.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>" +
                "<Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>" +
                "</Types>";
    }

    private static String rootRels() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/>" +
                "</Relationships>";
    }

    private static String workbook() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\">" +
                "<sheets>" +
                "<sheet name=\"OPD Records\" sheetId=\"1\" r:id=\"rId1\"/>" +
                "<sheet name=\"Summary\" sheetId=\"2\" r:id=\"rId2\"/>" +
                "</sheets></workbook>";
    }

    private static String workbookRels() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
                "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/>" +
                "<Relationship Id=\"rId2\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet2.xml\"/>" +
                "<Relationship Id=\"rId3\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles\" Target=\"styles.xml\"/>" +
                "</Relationships>";
    }

    private static String styles() {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<styleSheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">" +
                "<fonts count=\"2\"><font><sz val=\"11\"/><name val=\"Calibri\"/></font>" +
                "<font><b/><color rgb=\"FFFFFFFF\"/><sz val=\"11\"/><name val=\"Calibri\"/></font></fonts>" +
                "<fills count=\"3\"><fill><patternFill patternType=\"none\"/></fill><fill><patternFill patternType=\"gray125\"/></fill>" +
                "<fill><patternFill patternType=\"solid\"><fgColor rgb=\"FF0B5CAD\"/><bgColor indexed=\"64\"/></patternFill></fill></fills>" +
                "<borders count=\"1\"><border><left/><right/><top/><bottom/><diagonal/></border></borders>" +
                "<cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>" +
                "<cellXfs count=\"2\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>" +
                "<xf numFmtId=\"0\" fontId=\"1\" fillId=\"2\" borderId=\"0\" xfId=\"0\" applyFill=\"1\" applyFont=\"1\"/></cellXfs>" +
                "<cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles>" +
                "</styleSheet>";
    }

    private static String recordsSheet(List<VisitRecord> records) {
        StringBuilder s = new StringBuilder(16384);
        s.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
        s.append("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\">");
        s.append("<sheetViews><sheetView workbookViewId=\"0\"><pane ySplit=\"1\" topLeftCell=\"A2\" activePane=\"bottomLeft\" state=\"frozen\"/></sheetView></sheetViews>");
        s.append("<cols><col min=\"1\" max=\"1\" width=\"16\" customWidth=\"1\"/><col min=\"2\" max=\"2\" width=\"18\" customWidth=\"1\"/>");
        s.append("<col min=\"3\" max=\"6\" width=\"18\" customWidth=\"1\"/><col min=\"7\" max=\"7\" width=\"42\" customWidth=\"1\"/>");
        s.append("<col min=\"8\" max=\"9\" width=\"22\" customWidth=\"1\"/></cols>");
        s.append("<sheetData>");
        s.append("<row r=\"1\">");
        for (int i = 0; i < HEADERS.length; i++) s.append(cell(i, 1, HEADERS[i], 1));
        s.append("</row>");
        int row = 2;
        if (records != null) {
            for (VisitRecord r : records) {
                s.append("<row r=\"").append(row).append("\">");
                String[] vals = {r.mrNumber, r.contact, r.visitDate, r.visitType, r.nextAppointment, r.status, r.remarks, r.createdAt, r.updatedAt};
                for (int i = 0; i < vals.length; i++) s.append(cell(i, row, vals[i], 0));
                s.append("</row>");
                row++;
            }
        }
        s.append("</sheetData>");
        int last = Math.max(1, row - 1);
        s.append("<autoFilter ref=\"A1:I").append(last).append("\"/>");
        s.append("</worksheet>");
        return s.toString();
    }

    private static String summarySheet(List<VisitRecord> records, String scopeLabel) {
        int total = records == null ? 0 : records.size();
        int completed = 0, scheduled = 0, missed = 0, cancelled = 0;
        if (records != null) {
            for (VisitRecord r : records) {
                if ("Completed".equalsIgnoreCase(r.status)) completed++;
                else if ("Missed".equalsIgnoreCase(r.status)) missed++;
                else if ("Cancelled".equalsIgnoreCase(r.status)) cancelled++;
                else if ("Scheduled".equalsIgnoreCase(r.status) || "Rescheduled".equalsIgnoreCase(r.status)) scheduled++;
            }
        }
        String[][] rows = {
                {"BIDE Karachi OPD Registry Export", ""},
                {"Scope", scopeLabel == null ? "Export" : scopeLabel},
                {"Generated", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date())},
                {"Total records", String.valueOf(total)},
                {"Scheduled / Rescheduled", String.valueOf(scheduled)},
                {"Completed", String.valueOf(completed)},
                {"Missed", String.valueOf(missed)},
                {"Cancelled", String.valueOf(cancelled)}
        };
        StringBuilder s = new StringBuilder();
        s.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
        s.append("<worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><cols>");
        s.append("<col min=\"1\" max=\"1\" width=\"28\" customWidth=\"1\"/><col min=\"2\" max=\"2\" width=\"34\" customWidth=\"1\"/></cols><sheetData>");
        for (int i = 0; i < rows.length; i++) {
            int row = i + 1;
            s.append("<row r=\"").append(row).append("\">");
            s.append(cell(0, row, rows[i][0], i == 0 ? 1 : 0));
            s.append(cell(1, row, rows[i][1], i == 0 ? 1 : 0));
            s.append("</row>");
        }
        s.append("</sheetData></worksheet>");
        return s.toString();
    }

    private static String cell(int col, int row, String value, int style) {
        String ref = columnName(col) + row;
        return "<c r=\"" + ref + "\" t=\"inlineStr\" s=\"" + style + "\"><is><t xml:space=\"preserve\">" +
                xml(value == null ? "" : value) + "</t></is></c>";
    }

    private static String columnName(int zeroBased) {
        int n = zeroBased + 1;
        StringBuilder s = new StringBuilder();
        while (n > 0) {
            int rem = (n - 1) % 26;
            s.insert(0, (char)('A' + rem));
            n = (n - 1) / 26;
        }
        return s.toString();
    }

    private static String xml(String v) {
        StringBuilder out = new StringBuilder(v.length() + 16);
        for (int i = 0; i < v.length(); i++) {
            char c = v.charAt(i);
            switch (c) {
                case '&': out.append("&amp;"); break;
                case '<': out.append("&lt;"); break;
                case '>': out.append("&gt;"); break;
                case '"': out.append("&quot;"); break;
                case '\'': out.append("&apos;"); break;
                default:
                    if (c == 0x9 || c == 0xA || c == 0xD || c >= 0x20) out.append(c);
            }
        }
        return out.toString();
    }
}
