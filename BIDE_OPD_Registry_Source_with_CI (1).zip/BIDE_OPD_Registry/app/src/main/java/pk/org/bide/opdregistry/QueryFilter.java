package pk.org.bide.opdregistry;

public class QueryFilter {
    public String search = "";
    public String visitType = "All";
    public String status = "All";
    public String fromDate = "";
    public String toDate = "";
    public boolean upcomingOnly = false;
    public int upcomingDays = 30;
    public String sort = "Visit date (newest)";
}
