package pk.org.bide.opdregistry;

public class VisitRecord {
    public long visitId;
    public long patientId;
    public String mrNumber;
    public String contact;
    public String visitDate;
    public String visitType;
    public String nextAppointment;
    public String status;
    public String remarks;
    public String createdAt;
    public String updatedAt;
}
