package pk.org.bide.opdregistry;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;

public class CsvExporter {
    public static void write(OutputStream out, List<VisitRecord> records) throws Exception {
        StringBuilder s = new StringBuilder();
        s.append("MR Number,Contact Number,Visit Date,Visit Type,Next Appointment,Status,Remarks,Created At,Updated At\r\n");
        if (records != null) {
            for (VisitRecord r : records) {
                String[] vals = {r.mrNumber,r.contact,r.visitDate,r.visitType,r.nextAppointment,r.status,r.remarks,r.createdAt,r.updatedAt};
                for (int i = 0; i < vals.length; i++) {
                    if (i > 0) s.append(',');
                    s.append(q(vals[i]));
                }
                s.append("\r\n");
            }
        }
        out.write(s.toString().getBytes(StandardCharsets.UTF_8));
        out.flush();
    }

    private static String q(String v) {
        if (v == null) v = "";
        return '"' + v.replace("\"", "\"\"") + '"';
    }
}
