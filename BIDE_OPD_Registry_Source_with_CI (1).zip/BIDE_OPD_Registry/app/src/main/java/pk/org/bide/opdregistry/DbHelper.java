package pk.org.bide.opdregistry;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class DbHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "bide_opd_registry.db";
    private static final int DB_VERSION = 1;

    public DbHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE patients (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "mr_number TEXT NOT NULL UNIQUE COLLATE NOCASE," +
                "contact TEXT NOT NULL DEFAULT ''," +
                "created_at TEXT NOT NULL," +
                "updated_at TEXT NOT NULL)");

        db.execSQL("CREATE TABLE visits (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "patient_id INTEGER NOT NULL," +
                "visit_date TEXT NOT NULL," +
                "visit_type TEXT NOT NULL," +
                "next_appointment TEXT NOT NULL DEFAULT ''," +
                "status TEXT NOT NULL," +
                "remarks TEXT NOT NULL DEFAULT ''," +
                "created_at TEXT NOT NULL," +
                "updated_at TEXT NOT NULL," +
                "FOREIGN KEY(patient_id) REFERENCES patients(id) ON DELETE CASCADE)");

        db.execSQL("CREATE INDEX idx_visits_date ON visits(visit_date)");
        db.execSQL("CREATE INDEX idx_visits_next ON visits(next_appointment)");
        db.execSQL("CREATE INDEX idx_visits_status ON visits(status)");
        db.execSQL("CREATE INDEX idx_visits_type ON visits(visit_type)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Version 1 only. Future migrations should be added here without destructive reset.
    }

    public String today() {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
    }

    private String now() {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date());
    }

    private String datePlusDays(int days) {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DAY_OF_YEAR, days);
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(c.getTime());
    }

    public synchronized long saveVisit(VisitRecord r) throws Exception {
        if (r == null) throw new IllegalArgumentException("Record is required");
        String mr = clean(r.mrNumber);
        String contact = clean(r.contact);
        String visitDate = clean(r.visitDate);
        String visitType = clean(r.visitType);
        String next = clean(r.nextAppointment);
        String status = clean(r.status);
        String remarks = clean(r.remarks);
        if (mr.isEmpty()) throw new IllegalArgumentException("MR number is required");
        if (visitDate.isEmpty()) throw new IllegalArgumentException("Visit date is required");
        if (visitType.isEmpty()) throw new IllegalArgumentException("Visit type is required");
        if (status.isEmpty()) throw new IllegalArgumentException("Status is required");

        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            String ts = now();
            long patientId;
            if (r.visitId <= 0) {
                patientId = getPatientIdByMr(db, mr);
                if (patientId <= 0) {
                    ContentValues p = new ContentValues();
                    p.put("mr_number", mr);
                    p.put("contact", contact);
                    p.put("created_at", ts);
                    p.put("updated_at", ts);
                    patientId = db.insertOrThrow("patients", null, p);
                } else {
                    ContentValues p = new ContentValues();
                    p.put("contact", contact);
                    p.put("updated_at", ts);
                    db.update("patients", p, "id=?", new String[]{String.valueOf(patientId)});
                }

                ContentValues v = visitValues(patientId, visitDate, visitType, next, status, remarks, ts, ts);
                long id = db.insertOrThrow("visits", null, v);
                db.setTransactionSuccessful();
                return id;
            }

            long oldPatientId = getPatientIdForVisit(db, r.visitId);
            if (oldPatientId <= 0) throw new IllegalArgumentException("Visit no longer exists");
            String oldMr = getMrForPatient(db, oldPatientId);
            long targetPatientId = oldPatientId;

            if (!mr.equalsIgnoreCase(oldMr)) {
                long existing = getPatientIdByMr(db, mr);
                if (existing > 0 && existing != oldPatientId) {
                    targetPatientId = existing;
                    ContentValues existingP = new ContentValues();
                    existingP.put("contact", contact);
                    existingP.put("updated_at", ts);
                    db.update("patients", existingP, "id=?", new String[]{String.valueOf(existing)});
                } else {
                    ContentValues p = new ContentValues();
                    p.put("mr_number", mr);
                    p.put("contact", contact);
                    p.put("updated_at", ts);
                    db.update("patients", p, "id=?", new String[]{String.valueOf(oldPatientId)});
                }
            } else {
                ContentValues p = new ContentValues();
                p.put("contact", contact);
                p.put("updated_at", ts);
                db.update("patients", p, "id=?", new String[]{String.valueOf(oldPatientId)});
            }

            ContentValues v = new ContentValues();
            v.put("patient_id", targetPatientId);
            v.put("visit_date", visitDate);
            v.put("visit_type", visitType);
            v.put("next_appointment", next);
            v.put("status", status);
            v.put("remarks", remarks);
            v.put("updated_at", ts);
            db.update("visits", v, "id=?", new String[]{String.valueOf(r.visitId)});

            if (targetPatientId != oldPatientId) deletePatientIfOrphan(db, oldPatientId);
            db.setTransactionSuccessful();
            return r.visitId;
        } finally {
            db.endTransaction();
        }
    }

    private ContentValues visitValues(long patientId, String visitDate, String visitType,
                                      String next, String status, String remarks,
                                      String created, String updated) {
        ContentValues v = new ContentValues();
        v.put("patient_id", patientId);
        v.put("visit_date", visitDate);
        v.put("visit_type", visitType);
        v.put("next_appointment", next);
        v.put("status", status);
        v.put("remarks", remarks);
        v.put("created_at", created);
        v.put("updated_at", updated);
        return v;
    }

    public synchronized boolean deleteVisit(long visitId) {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            long patientId = getPatientIdForVisit(db, visitId);
            int n = db.delete("visits", "id=?", new String[]{String.valueOf(visitId)});
            if (patientId > 0) deletePatientIfOrphan(db, patientId);
            db.setTransactionSuccessful();
            return n > 0;
        } finally {
            db.endTransaction();
        }
    }

    private void deletePatientIfOrphan(SQLiteDatabase db, long patientId) {
        Cursor c = db.rawQuery("SELECT COUNT(*) FROM visits WHERE patient_id=?", new String[]{String.valueOf(patientId)});
        try {
            if (c.moveToFirst() && c.getInt(0) == 0) {
                db.delete("patients", "id=?", new String[]{String.valueOf(patientId)});
            }
        } finally { c.close(); }
    }

    public String findContactByMr(String mr) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT contact FROM patients WHERE mr_number=? COLLATE NOCASE LIMIT 1",
                new String[]{clean(mr)});
        try {
            return c.moveToFirst() ? c.getString(0) : "";
        } finally { c.close(); }
    }

    public VisitRecord getVisit(long id) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery(baseSelect() + " WHERE v.id=?", new String[]{String.valueOf(id)});
        try {
            return c.moveToFirst() ? fromCursor(c) : null;
        } finally { c.close(); }
    }

    public List<VisitRecord> query(QueryFilter f) {
        if (f == null) f = new QueryFilter();
        SQLiteDatabase db = getReadableDatabase();
        StringBuilder sql = new StringBuilder(baseSelect()).append(" WHERE 1=1");
        ArrayList<String> args = new ArrayList<>();

        String s = clean(f.search);
        if (!s.isEmpty()) {
            sql.append(" AND (p.mr_number LIKE ? OR p.contact LIKE ? OR v.remarks LIKE ?)");
            String q = "%" + s + "%";
            args.add(q); args.add(q); args.add(q);
        }
        if (f.visitType != null && !"All".equals(f.visitType)) {
            sql.append(" AND v.visit_type=?"); args.add(f.visitType);
        }
        if (f.status != null && !"All".equals(f.status)) {
            sql.append(" AND v.status=?"); args.add(f.status);
        }
        if (!clean(f.fromDate).isEmpty()) {
            sql.append(" AND v.visit_date>=?"); args.add(f.fromDate);
        }
        if (!clean(f.toDate).isEmpty()) {
            sql.append(" AND v.visit_date<=?"); args.add(f.toDate);
        }
        if (f.upcomingOnly) {
            sql.append(" AND v.next_appointment<>'' AND v.next_appointment>=? AND v.next_appointment<=?");
            args.add(today()); args.add(datePlusDays(Math.max(1, f.upcomingDays)));
        }

        if ("Next appointment (soonest)".equals(f.sort)) {
            sql.append(" ORDER BY CASE WHEN v.next_appointment='' THEN 1 ELSE 0 END, v.next_appointment ASC, v.id DESC");
        } else if ("MR number".equals(f.sort)) {
            sql.append(" ORDER BY p.mr_number COLLATE NOCASE ASC, v.visit_date DESC");
        } else if ("Visit date (oldest)".equals(f.sort)) {
            sql.append(" ORDER BY v.visit_date ASC, v.id ASC");
        } else {
            sql.append(" ORDER BY v.visit_date DESC, v.id DESC");
        }

        Cursor c = db.rawQuery(sql.toString(), args.toArray(new String[0]));
        ArrayList<VisitRecord> out = new ArrayList<>();
        try {
            while (c.moveToNext()) out.add(fromCursor(c));
        } finally { c.close(); }
        return out;
    }

    public List<VisitRecord> patientHistory(String mr) {
        QueryFilter f = new QueryFilter();
        f.search = mr;
        List<VisitRecord> all = query(f);
        ArrayList<VisitRecord> exact = new ArrayList<>();
        for (VisitRecord r : all) if (r.mrNumber.equalsIgnoreCase(clean(mr))) exact.add(r);
        return exact;
    }

    public List<VisitRecord> todayVisits() {
        QueryFilter f = new QueryFilter();
        f.fromDate = today();
        f.toDate = today();
        return query(f);
    }

    public Map<String, Integer> dashboardCounts() {
        HashMap<String, Integer> m = new HashMap<>();
        SQLiteDatabase db = getReadableDatabase();
        m.put("patients", scalar(db, "SELECT COUNT(*) FROM patients", null));
        m.put("visits", scalar(db, "SELECT COUNT(*) FROM visits", null));
        m.put("today", scalar(db, "SELECT COUNT(*) FROM visits WHERE visit_date=?", new String[]{today()}));
        m.put("upcoming7", scalar(db, "SELECT COUNT(*) FROM visits WHERE next_appointment<>'' AND next_appointment>=? AND next_appointment<=?",
                new String[]{today(), datePlusDays(7)}));
        m.put("scheduled", scalar(db, "SELECT COUNT(*) FROM visits WHERE status IN ('Scheduled','Rescheduled')", null));
        m.put("completed", scalar(db, "SELECT COUNT(*) FROM visits WHERE status='Completed'", null));
        m.put("missed", scalar(db, "SELECT COUNT(*) FROM visits WHERE status='Missed'", null));
        return m;
    }

    private int scalar(SQLiteDatabase db, String sql, String[] args) {
        Cursor c = db.rawQuery(sql, args);
        try { return c.moveToFirst() ? c.getInt(0) : 0; }
        finally { c.close(); }
    }

    public JSONObject exportJson() throws Exception {
        SQLiteDatabase db = getReadableDatabase();
        JSONObject root = new JSONObject();
        root.put("format", "BIDE_OPD_BACKUP_V1");
        root.put("exported_at", now());
        JSONArray patients = new JSONArray();
        Cursor p = db.rawQuery("SELECT id,mr_number,contact,created_at,updated_at FROM patients ORDER BY id", null);
        try {
            while (p.moveToNext()) {
                JSONObject o = new JSONObject();
                o.put("id", p.getLong(0));
                o.put("mr_number", p.getString(1));
                o.put("contact", p.getString(2));
                o.put("created_at", p.getString(3));
                o.put("updated_at", p.getString(4));
                patients.put(o);
            }
        } finally { p.close(); }
        JSONArray visits = new JSONArray();
        Cursor v = db.rawQuery("SELECT id,patient_id,visit_date,visit_type,next_appointment,status,remarks,created_at,updated_at FROM visits ORDER BY id", null);
        try {
            while (v.moveToNext()) {
                JSONObject o = new JSONObject();
                o.put("id", v.getLong(0));
                o.put("patient_id", v.getLong(1));
                o.put("visit_date", v.getString(2));
                o.put("visit_type", v.getString(3));
                o.put("next_appointment", v.getString(4));
                o.put("status", v.getString(5));
                o.put("remarks", v.getString(6));
                o.put("created_at", v.getString(7));
                o.put("updated_at", v.getString(8));
                visits.put(o);
            }
        } finally { v.close(); }
        root.put("patients", patients);
        root.put("visits", visits);
        return root;
    }

    public synchronized void importJson(JSONObject root) throws Exception {
        if (root == null || !"BIDE_OPD_BACKUP_V1".equals(root.optString("format"))) {
            throw new IllegalArgumentException("This is not a BIDE OPD Registry backup file");
        }
        JSONArray patients = root.getJSONArray("patients");
        JSONArray visits = root.getJSONArray("visits");
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            db.delete("visits", null, null);
            db.delete("patients", null, null);
            for (int i = 0; i < patients.length(); i++) {
                JSONObject o = patients.getJSONObject(i);
                ContentValues cv = new ContentValues();
                cv.put("id", o.getLong("id"));
                cv.put("mr_number", o.getString("mr_number"));
                cv.put("contact", o.optString("contact", ""));
                cv.put("created_at", o.optString("created_at", now()));
                cv.put("updated_at", o.optString("updated_at", now()));
                db.insertOrThrow("patients", null, cv);
            }
            for (int i = 0; i < visits.length(); i++) {
                JSONObject o = visits.getJSONObject(i);
                ContentValues cv = new ContentValues();
                cv.put("id", o.getLong("id"));
                cv.put("patient_id", o.getLong("patient_id"));
                cv.put("visit_date", o.getString("visit_date"));
                cv.put("visit_type", o.getString("visit_type"));
                cv.put("next_appointment", o.optString("next_appointment", ""));
                cv.put("status", o.getString("status"));
                cv.put("remarks", o.optString("remarks", ""));
                cv.put("created_at", o.optString("created_at", now()));
                cv.put("updated_at", o.optString("updated_at", now()));
                db.insertOrThrow("visits", null, cv);
            }
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }

    public synchronized void deleteAllData() {
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            db.delete("visits", null, null);
            db.delete("patients", null, null);
            db.setTransactionSuccessful();
        } finally { db.endTransaction(); }
    }

    private long getPatientIdByMr(SQLiteDatabase db, String mr) {
        Cursor c = db.rawQuery("SELECT id FROM patients WHERE mr_number=? COLLATE NOCASE LIMIT 1", new String[]{mr});
        try { return c.moveToFirst() ? c.getLong(0) : -1; }
        finally { c.close(); }
    }

    private long getPatientIdForVisit(SQLiteDatabase db, long visitId) {
        Cursor c = db.rawQuery("SELECT patient_id FROM visits WHERE id=?", new String[]{String.valueOf(visitId)});
        try { return c.moveToFirst() ? c.getLong(0) : -1; }
        finally { c.close(); }
    }

    private String getMrForPatient(SQLiteDatabase db, long patientId) {
        Cursor c = db.rawQuery("SELECT mr_number FROM patients WHERE id=?", new String[]{String.valueOf(patientId)});
        try { return c.moveToFirst() ? c.getString(0) : ""; }
        finally { c.close(); }
    }

    private String baseSelect() {
        return "SELECT v.id,p.id,p.mr_number,p.contact,v.visit_date,v.visit_type,v.next_appointment,v.status,v.remarks,v.created_at,v.updated_at " +
                "FROM visits v JOIN patients p ON p.id=v.patient_id";
    }

    private VisitRecord fromCursor(Cursor c) {
        VisitRecord r = new VisitRecord();
        r.visitId = c.getLong(0);
        r.patientId = c.getLong(1);
        r.mrNumber = n(c.getString(2));
        r.contact = n(c.getString(3));
        r.visitDate = n(c.getString(4));
        r.visitType = n(c.getString(5));
        r.nextAppointment = n(c.getString(6));
        r.status = n(c.getString(7));
        r.remarks = n(c.getString(8));
        r.createdAt = n(c.getString(9));
        r.updatedAt = n(c.getString(10));
        return r;
    }

    private String clean(String s) { return s == null ? "" : s.trim(); }
    private String n(String s) { return s == null ? "" : s; }
}
